// public/scripts/main.js
$(document).ready(function() {
    console.log("Page loaded");
  });
  