// modules/config.js
module.exports = {
    port: 3000,
    dbUri: 'mongodb+srv://adedralin:gelo@fullstackwebdev.mgiw3lo.mongodb.net/?retryWrites=true&w=majority&appName=fullstackwebdev'
  };
