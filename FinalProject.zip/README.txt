Angelo Edralin
20649817
I wrote javascript code and made hbs files
Some problems I came up with involved syntax with some app statements and linking up to the database.
I worked out the problems on my own looking at past class examples and worked together with Isaiah Walker.